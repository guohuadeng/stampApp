<?php
    class Sunpop_StampCustomer_Model_Mysql4_Stampcustomer_Collection extends Mage_Core_Model_Mysql4_Collection_Abstract
    {

		public function _construct(){
			$this->_init("stampcustomer/stampcustomer");
		}

		

    }
	 